<?php
  $cnn=mysqli_connect("localhost","root","") or die("not connected .....");
  mysqli_select_db($cnn,"connect");
?>