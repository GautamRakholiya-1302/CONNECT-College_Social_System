<?php
   	require_once('session.php');
  	include("connection.php"); 
  	require_once("header.php");
?>
<section class="register-now section-padding-100 d-flex justify-content-between align-items-center" style="background-image: url(img/core-img/texture.png);">

  <div class="container-fluid">
      <div class="row" style="margin-left: 20%;width: 700px; background-color: white;">
        <div class="col-lg-12">
          <h3 class="text-primary">Requests </h3><br><br>
            
        </div>
    </div>
  </div>
</section>
<?php
    require_once("../Layout/footer.php");
?>
