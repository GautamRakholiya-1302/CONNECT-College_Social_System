<?php
	include("connection.php");

	echo $_REQUEST['postid'];
?>